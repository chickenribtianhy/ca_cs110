#!/bin/bash
gcc -c ringbuffer.c -fPIC -shared -Wpedantic -Wall -Wextra -Werror -std=c89 -o libringbuffer.so
gcc -c test.c -Wpedantic -Wall -Wextra -Werror -std=c89 -o test.o
gcc -o dynamicringbuffer test.o libringbuffer.so